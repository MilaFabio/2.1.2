<div class="wrap">
<form method="post" enctype="multipart/form-data">
<div id="icon-edit" class="icon32"></div><h2>WPGrabber - Импорт</h2><br>
<input type="file" name="file" />
<?php submit_button('Импортировать файл'); ?>
</form>