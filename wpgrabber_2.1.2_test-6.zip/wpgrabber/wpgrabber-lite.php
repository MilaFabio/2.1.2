<?php
/**
@package WPGrabber
Plugin Name: WPGrabber Lite
Plugin URI: http://wpgrabber.biz
Description: WordPess Grabber plugin
Version: 2.1.2  Lite Test - 6 (26.08.2016)
Author: GrabTeam (close) - new WPGrabber_Biz
Author URI: http://wpgrabber.biz
*/
  if (defined('WPGRABBER_VERSION')) {
    die('На сайте активирован плагин WPGrabber версии '.WPGRABBER_VERSION.'. Пожалуйста, деактивируйте его перед активацией данного плагина.');
  }
  define('WPGRABBER_VERSION', '2.1.2');

  define('WPGRABBER_PLUGIN_DIR', plugin_dir_path( __FILE__ ));
  define('WPGRABBER_PLUGIN_URL', plugin_dir_url( __FILE__ ));
  define('WPGRABBER_PLUGIN_FILE', __FILE__);

  require WPGRABBER_PLUGIN_DIR.'init.php';
?>