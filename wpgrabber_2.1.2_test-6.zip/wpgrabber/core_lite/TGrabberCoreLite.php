<?php
/**
* TGrabberCore
*
* @version 1.1
* @author GrabTeam <gfk@mail.ru>
* @copyright 2009-2014 GrabTeam (closed)
* @link http://wpgrabber.biz
*/

  class TGrabberCoreLite extends TGrabberWordPress {

  }
