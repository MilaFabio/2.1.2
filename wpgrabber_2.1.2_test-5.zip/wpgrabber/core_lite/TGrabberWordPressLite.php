<?php
/**
* TGrabberWordPress
*
* @version 1.1.6
* @author GrabTeam <gfk@mail.ru>
* @copyright 2009-2014 GrabTeam
* @link http://wpgrabber.ru
*/

  class TGrabberWordPressLite extends TGrabberCoreLite {

  }