<?php
  class WPGPluginLite extends WPGPlugin {

  }
?>